# Telegram Bot

A simple Telegram bot built with [python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot).

## Setup

1. Create a bot via [@BotFather](https://t.me/BotFather) on Telegram and copy the token.
2. Set the `TELEGRAM_BOT_TOKEN` environment secret.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the bot:
   ```bash
   python main.py
   ```

## Commands

| Command | Description |
|---------|-------------|
| `/start` | Welcome message |
| `/help`  | List available commands |

Any non-command text message is echoed back to the user.

## Project structure

```
telegram-bot/
├── main.py          # Bot entry point and handlers
├── requirements.txt # Python dependencies
└── README.md        # This file
```
