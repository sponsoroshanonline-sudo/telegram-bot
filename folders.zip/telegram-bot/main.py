import logging
import os

from google import genai
from google.genai import types
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "ඔබ විශේෂඥ සිංහල සමාජ මාධ්‍ය ලේඛකයෙකි. "
    "පරිශීලකයා රැකියා විස්තරයක් හෝ ඕනෑම පණිවිඩයක් ලබා දෙන විට, "
    "ඔබ ඒ සඳහා ආකර්ශනීය, චිත්තාකර්ශනීය සිංහල සමාජ මාධ්‍ය පළ කිරීමක් නිර්මාණය කළ යුතුය. "
    "සෑම පළ කිරීමකම:\n"
    "- සිංහල භාෂාව පමණක් භාවිත කරන්න\n"
    "- ආකර්ශනීය ශීර්ෂයක් ඇතුළත් කරන්න\n"
    "- අදාළ ඉමොජි බහුලව භාවිත කරන්න\n"
    "- ප්‍රේක්ෂකයන් සම්බන්ධ කර ගන්නා ස්වරයක් භාවිත කරන්න\n"
    "- හැෂ් ටැග් (Sinhala හෝ English) ඇතුළත් කරන්න\n"
    "- Facebook, Instagram හෝ LinkedIn සඳහා සුදුසු ලෙස සකස් කරන්න\n"
    "පළ කිරීම පමණක් ලිවිය යුතු අතර අමතර පැහැදිලි කිරීම් අවශ්‍ය නොවේ."
)


def get_gemini_client() -> genai.Client:
    """Return a configured Gemini client."""
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY environment variable is not set.")
    return genai.Client(api_key=api_key)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a welcome message when /start is issued."""
    user = update.effective_user
    await update.message.reply_html(
        f"ආයුබෝවන් {user.mention_html()}! 🙏\n\n"
        "ඔබගේ රැකියා විස්තරය හෝ ඕනෑම පණිවිඩයක් මට එවන්න.\n"
        "මම එය ආකර්ශනීය <b>සිංහල සමාජ මාධ්‍ය පළ කිරීමක්</b> බවට පරිවර්තනය කරන්නම්! ✨\n\n"
        "/help — උදව් දක්වන්න"
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a help message when /help is issued."""
    help_text = (
        "🤖 *සිංහල සමාජ මාධ්‍ය Post Generator*\n\n"
        "ඔබගේ රැකියා විස්තරය හෝ ඕනෑම අදහසක් ටයිප් කරන්න — "
        "මම Gemini AI භාවිතයෙන් ආකර්ශනීය සිංහල Social Media Post එකක් නිර්මාණය කරන්නම්! 🌟\n\n"
        "*Commands:*\n"
        "/start — ආරම්භ කරන්න\n"
        "/help — මෙය දක්වන්න"
    )
    await update.message.reply_text(help_text, parse_mode="Markdown")


async def generate_post(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Generate a Sinhala social media post from user's text using Gemini."""
    user_text = update.message.text
    thinking_msg = await update.message.reply_text(
        "⏳ Gemini AI සමඟ සිංහල Post එක සකස් කරමින් පවතී..."
    )

    try:
        client = get_gemini_client()
        response = await client.aio.models.generate_content(
            model="gemini-1.5-flash",
            contents=user_text,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
                temperature=0.9,
            ),
        )
        generated_post = response.text.strip()

        await thinking_msg.edit_text(
            f"✅ *ඔබගේ සිංහල Social Media Post එක සූදානම්!*\n\n{generated_post}",
            parse_mode="Markdown",
        )
    except Exception as e:
        logger.error("Gemini generation failed: %s", e)
        await thinking_msg.edit_text(
            "❌ සමාවන්න, Post එක සෑදීමේදී දෝෂයක් ඇති විය. නැවත උත්සාහ කරන්න."
        )


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log errors caused by updates."""
    logger.error("Exception while handling an update:", exc_info=context.error)


def main() -> None:
    """Start the bot."""
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN environment variable is not set.")

    application = Application.builder().token(token).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, generate_post))
    application.add_error_handler(error_handler)

    logger.info("Bot is starting with Gemini AI integration...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
